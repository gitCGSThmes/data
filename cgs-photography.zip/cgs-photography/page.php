<?php get_header(); ?>
<?php
$cgs_photography_show_inner_banner = get_post_meta(get_the_ID(), 'cgs_photography_show_inner_banner', true);
$cgs_photography_banner_image = get_field('cgs_photography_banner_image');
if($cgs_photography_banner_image){
    $innerbanner_styles = 'style="background: url('.$cgs_photography_banner_image.')"';
}else{
    $innerbanner_styles = '';
}
$cgs_photography_title_on_banner = get_post_meta(get_the_ID(), 'cgs_photography_title_on_banner', true);
$cgs_photography_title_color = get_post_meta(get_the_ID(), 'cgs_photography_title_color', true);
$cgs_photography_title_alignment = get_post_meta(get_the_ID(), 'cgs_photography_title_alignment', true);
?>

<?php if($cgs_photography_show_inner_banner == 'yes' || $cgs_photography_show_inner_banner == ''){ ?>
    <div class="inner-banner" <?php echo $innerbanner_styles; ?> >
        <div class="container">
            <?php if(!empty($cgs_photography_title_on_banner)){ ?>
                <h1 style="color: <?php echo $cgs_photography_title_color; ?>; text-align: <?php echo $cgs_photography_title_alignment; ?>;"><?php echo $cgs_photography_title_on_banner; ?></h1>
            <?php } ?>
        </div>
    </div>
    <style>
        .inner-banner h1:after{
            border-top: 1px solid <?php echo $cgs_photography_title_color; ?>;
        }
    </style>
<?php } ?>
<div class="main-content-wrapper">
    <div class="container">
		<?php $cgs_fashion_trend_page_layout = esc_html(get_post_meta(get_the_ID(), 'cgs_fashion_trend_page_layout', true)); ?>
		<?php $cgs_fashion_trend_pages_default_layout = get_theme_mod('cgs_fashion_trend_pages_default_layout'); ?>
		<?php if($cgs_fashion_trend_page_layout == '' || $cgs_fashion_trend_page_layout == 'default_layout'){ ?>
			<?php if($cgs_fashion_trend_pages_default_layout == 'left_sidebar'){ ?>
                <div class="row">
                    <div class="col-xl-3"><?php get_sidebar(); ?></div>
                    <div class="col-xl-9">
						<?php if(have_posts()){ ?>
                            <div class="row">
								<?php while(have_posts()) : the_post(); ?>
									<?php get_template_part( 'content' ); ?>
								<?php endwhile; ?>
                            </div>
						<?php } ?>
                    </div>
                </div>
			<?php } elseif($cgs_fashion_trend_pages_default_layout == 'no_sidebar_full_width') { ?>
                <div class="row">
                    <div class="col-xl-12">
						<?php if(have_posts()){ ?>
                            <div class="row">
								<?php while(have_posts()) : the_post(); ?>
									<?php get_template_part( 'content' ); ?>
								<?php endwhile; ?>
                            </div>
						<?php } ?>
                    </div>
                </div>
			<?php } else { ?>
                <div class="row">
                    <div class="col-xl-9">
						<?php if(have_posts()){ ?>
                            <div class="row">
								<?php while(have_posts()) : the_post(); ?>
									<?php get_template_part( 'content' ); ?>
								<?php endwhile; ?>
                            </div>
						<?php } ?>
                    </div>
                    <div class="col-xl-3"><?php get_sidebar(); ?></div>
                </div>
			<?php } ?>
		<?php } elseif($cgs_fashion_trend_page_layout == 'right_sidebar'){ ?>
            <div class="row">
                <div class="col-xl-9">
					<?php if(have_posts()){ ?>
                        <div class="row">
							<?php while(have_posts()) : the_post(); ?>
								<?php get_template_part( 'content' ); ?>
							<?php endwhile; ?>
                        </div>
					<?php } ?>
                </div>
                <div class="col-xl-3"><?php get_sidebar(); ?></div>
            </div>
		<?php } elseif($cgs_fashion_trend_page_layout == 'left_sidebar'){ ?>
            <div class="row">
                <div class="col-xl-3"><?php get_sidebar(); ?></div>
                <div class="col-xl-9">
					<?php if(have_posts()){ ?>
                        <div class="row">
							<?php while(have_posts()) : the_post(); ?>
								<?php get_template_part( 'content' ); ?>
							<?php endwhile; ?>
                        </div>
					<?php } ?>
                </div>
            </div>
		<?php } elseif($cgs_fashion_trend_page_layout == 'no_sidebar_full_width'){ ?>
            <div class="row">
                <div class="col-xl-12">
					<?php if(have_posts()){ ?>
                        <div class="row">
							<?php while(have_posts()) : the_post(); ?>
								<?php get_template_part( 'content' ); ?>
							<?php endwhile; ?>
                        </div>
					<?php } ?>
                </div>
            </div>
		<?php } elseif($cgs_fashion_trend_page_layout == 'no_sidebar_content_centered'){ ?>
            <div class="row">
                <div class="col-xl-1"></div>
                <div class="col-xl-10">
					<?php if(have_posts()){ ?>
                        <div class="row">
							<?php while(have_posts()) : the_post(); ?>
								<?php get_template_part( 'content' ); ?>
							<?php endwhile; ?>
                        </div>
					<?php } ?>
                </div>
                <div class="col-xl-1"></div>
            </div>
		<?php } ?>
    </div>
</div>
<?php get_footer(); ?>
